package program.ProbIA;

import aima.search.framework.GoalTest;


public class ProbIAGoalTest implements GoalTest {

  public boolean isGoalState(Object aState) {
    return(false);
  }

}
