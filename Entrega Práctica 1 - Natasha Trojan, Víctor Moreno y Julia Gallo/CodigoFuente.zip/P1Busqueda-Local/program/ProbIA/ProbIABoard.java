package program.ProbIA;

// import javadoc.javadoc.IA.Azamon;
import IA.Azamon.Paquetes;
import IA.Azamon.Oferta;
import IA.Azamon.Paquete;
import IA.Azamon.Transporte;

import java.io.File;
import java.util.*;
import java.util.stream.IntStream;
import java.util.stream.Collectors;
import java.io.FileWriter;
import java.io.IOException;

public class ProbIABoard {
  // Paquetes y ofertas que definen el problema (no estoy seguro que se tenga que poner)
  static Paquetes paquetes;
  static Transporte ofertas;

  // Registro de la asignacion de un paquete a una oferta (id del paquete, id de la oferta a la que se asigna)
  public List<Map.Entry<Integer, Integer>> asignacionPaquetes;

  // Separacion de las ofertas segun su prioridad (id de la oferta sobre vector ofertas totales, peso libre)
  public List<Map.Entry<Integer, Double>> asignacionOfertas;

  //(id paquete indice prioridad)
  public List<Map.Entry<Integer, Integer>> paqsOrdenats;

  public Double costeAsignacion;

  public Integer felicidad;

  public Double getCoste() {return costeAsignacion;}
  public Integer getFelicidad() {return felicidad;}

  public List<Map.Entry<Integer, Integer>> getAsignacionPaquetes() {return asignacionPaquetes;}
  public List<Map.Entry<Integer, Double>> getAsignacionOfertas() {return asignacionOfertas;}


  public int getState(){return state;}
  public int getHeuristico() {return heuristico;}

  // Contadores para la solucion inicial secuencial

  public int numPaquetes;
  public int numeroOfertas;


  public ProbIABoard (List<Map.Entry<Integer, Integer>> asignacionPaquetesPadre, List<Map.Entry<Integer, Double>> ofertasPadre, double costeP, Integer felP) {

    asignacionPaquetes = new ArrayList<>();
    for (Map.Entry<Integer, Integer> entry : asignacionPaquetesPadre) {
      this.asignacionPaquetes.add(new AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue()));

    }

    this.asignacionOfertas = new ArrayList<>();
    for (Map.Entry<Integer, Double> entry : ofertasPadre) {
      asignacionOfertas.add(new AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue()));
    }
    costeAsignacion = costeP;
    felicidad = felP;
  }


  public int heuristico;

  public int state;


  // Estado inicial
  public ProbIABoard (Paquetes paqs, Transporte transporte, int s, int h) {
    // Guardar los paquetes y ofertas de este problema
    paquetes = paqs;
    ofertas = transporte;

    numPaquetes = paqs.size();
    heuristico = h;
    state = s;
    asignacionPaquetes = new ArrayList<>();
    asignacionOfertas = new ArrayList<>();
    costeAsignacion = 0.0;
    felicidad = 0;

    // Inicializar la asignacion y los contadores

    numeroOfertas = transporte.size();
    //System.out.println("ofertas:");
    for (int ofertaIndex = 0; ofertaIndex < numeroOfertas; ++ofertaIndex) {
      // Preparar el ÃƒÆ’Ã‚Â­ndice de la oferta en transporte, y el peso libre
      Oferta o = transporte.get(ofertaIndex);
      Map.Entry<Integer, Double> oferta = new AbstractMap.SimpleEntry<>(ofertaIndex, o.getPesomax());
      int dias = o.getDias();
      asignacionOfertas.add(oferta);
    }
    paqsOrdenats = new ArrayList<>();

    for (int i = 0; i < paquetes.size(); ++i) {
      int prio = paquetes.get(i).getPrioridad();
      paqsOrdenats.add(new AbstractMap.SimpleEntry<>(i, prio));
    }

    //ordenacion de los paquetes
    Collections.sort(paqsOrdenats, new Comparator<Map.Entry<Integer, Integer>>() {
      @Override
      public int compare(Map.Entry<Integer, Integer> entry1, Map.Entry<Integer, Integer> entry2) {
        return Integer.compare(entry1.getValue(), entry2.getValue());
      }
    });

    /* Paquets ordena bÃƒÂ©
    for (int i = 0; i < paqsOrdenats.size(); ++i) {
      System.out.println("paq " + paqsOrdenats.get(i).getKey() + " prio " + paqsOrdenats.get(i).getValue());
    }
    */

    if (state == 0) SolucionInicialRandom();
    else solucionInicialSecuencial();

  }

  // Solucion inicial random
  public void SolucionInicialRandom() {
    //System.out.println("AsignacionInicialAleatoria");
    for (int p = 0; p < paqsOrdenats.size(); ++p) {
      Paquete paq = paquetes.get(paqsOrdenats.get(p).getKey());
      int prioridad = paq.getPrioridad();
      double peso = paq.getPeso();
      //System.out.println("paq " + p + " prio "+paq.getPrioridad());
      boolean asignado = false;
      asignado = asignarPaqueteAOfertaAleatoria(paqsOrdenats.get(p).getKey(), peso, prioridad);
      if (!asignado) System.out.println("Paquete con peso " + paqsOrdenats.get(p).getKey() + " no ha sido asignado ");
    }
    calcularCoste(this);
    calcularFelicidad(this);
  }


  // Asignar paquete a oferta random de su prioridad o mayor (prioridad valida)
  public boolean asignarPaqueteAOfertaAleatoria(int indexPaq, double peso, int prioridadPaquete) {
    Random random = new Random(); // Random(ofertas.size())??
    // Intentar asignar el paquete a cualquier oferta en la lista mezclada
    boolean asignado = false;

    List<Integer> indices = IntStream.range(0, numeroOfertas).boxed().collect(Collectors.toList());
    Collections.shuffle(indices);
    for (int i = 0; !asignado && i < numeroOfertas; ++i) {
      int r = indices.get(i);
      int indexOf = asignacionOfertas.get(r).getKey();
      int prioO = getPrioridad(ofertas.get(indexOf).getDias());

      if (prioO <= prioridadPaquete) {
        double pesoLibre = asignacionOfertas.get(r).getValue();
        if (pesoLibre >= peso) {
          // Actualizar el peso disponible de la oferta
          double nuevoPesoLibre = pesoLibre - peso;
          asignacionOfertas.set(indexOf, new AbstractMap.SimpleEntry<>(indexOf, nuevoPesoLibre));
          // Registrar la asignaciÃƒÆ’Ã‚Â³n del paquete
          //System.out.println("paq " + indexPaq + " priopaq "+ prioridadPaquete+"assignat a oferta " + indexOf + " amb prio " +prioO);
          asignacionPaquetes.add(new AbstractMap.SimpleEntry<>(indexPaq, indexOf));
          asignado = true;
        }
      }
    }
    return asignado; // No se pudo asignar el paquete a ninguna oferta en la lista de la prioridad actual
  }

  // Solucion inicial secuencial
  public void solucionInicialSecuencial() {
    for (int p = 0; p < paqsOrdenats.size(); ++p) {
      Paquete paq = paquetes.get(paqsOrdenats.get(p).getKey());
      int prioridad = paq.getPrioridad();
      double peso = paq.getPeso();
      int indiceP = paqsOrdenats.get(p).getKey();
      boolean asignado = false;
      // Intentar asignar el paquete basado en su prioridad
      asignado = asignarPaqueteAOfertaSecuencial(indiceP, peso, prioridad);
      if (!asignado) System.out.println("Paquete con peso " + peso + " no ha sido asignado a ninguna oferta.");
      if (asignado) System.out.println("Paquete " + indiceP + " ha sido asignado");
      //if (asignado) System.out.println("Paq " + indiceP + " asignado a oferta " + asignacionPaquetes.get(indiceP).getValue());
    }
    calcularCoste(this);
    calcularFelicidad(this);
  }

  // Asignar paquete a la primera oferta secuencialmente validad (igual o mayor prioridad)
  public boolean asignarPaqueteAOfertaSecuencial(int indexPaq, double peso, int prioridadPaq) {
    double pesoLibre;
    int indexOferta;
    boolean asignado = false;
    int i = 0;
    while (!asignado && i < numeroOfertas) {
      Map.Entry<Integer, Double> oferta = asignacionOfertas.get(i);

      int prioO = getPrioridad(ofertas.get(i).getDias());
      if (prioO <= prioridadPaq) {
        if (oferta.getValue() >= peso) {
          // Actualizar el peso disponible de la oferta
          double nuevoPesoLibre = oferta.getValue() - peso;
          asignacionOfertas.set(oferta.getKey(), new AbstractMap.SimpleEntry<>(oferta.getKey(), nuevoPesoLibre));
          asignacionPaquetes.add(new AbstractMap.SimpleEntry<>(indexPaq, oferta.getKey()));
          asignado = true;
        }
      }
      ++i;
    }
    return asignado; // No se pudo asignar el paquete a ninguna oferta en la lista de la prioridad actual
  }


  // GETTERS

  public int getOfertasnum () {
    return numeroOfertas;

  }

  public boolean prioridadCorrecta(int prioridad, int diasOferta) {
    if (diasOferta == 1) return true;
    else if (diasOferta == 2 || diasOferta == 3 && prioridad != 0) return true;
    else return diasOferta == 4 || diasOferta == 5 && prioridad == 2;
  }


  public int getPrioridad (int dias) {
    if (dias == 1) return 0;
    else if (dias == 2 || dias == 3) return 1;
    else return 2;
  }


  public boolean moverPaqueteMismaPrioridad(int indicePaq, int indiceNuevaOferta, double nuevoPesoLibre) {
    int indiceOfertaActual = asignacionPaquetes.get(indicePaq).getValue();
    double pesoLibreActual = asignacionOfertas.get(indiceOfertaActual).getValue();
    //intentamos mover
    if (nuevoPesoLibre >= 0 && indiceOfertaActual != indiceNuevaOferta) {
      asignacionPaquetes.set(indicePaq, new AbstractMap.SimpleEntry<>(indicePaq, indiceNuevaOferta));
      asignacionOfertas.set(indiceNuevaOferta, new AbstractMap.SimpleEntry<>(indiceNuevaOferta, nuevoPesoLibre));
      //volvemos a actualizar el peso libre de la oferta anterior
      double pesoRecalculado = pesoLibreActual+paquetes.get(indicePaq).getPeso();
      asignacionOfertas.set(indiceOfertaActual, new AbstractMap.SimpleEntry<>(indiceNuevaOferta, pesoRecalculado));

      editarCoste(indicePaq, indiceOfertaActual, indiceNuevaOferta);
      return true;
    }
    return false;
  }


  public boolean mejorarPrioridadPaquete(int indiceP, int indiceONueva, int prioONueva) {
    // Obtener el peso del paquete y su prioridad actual
    double pesoP = paquetes.get(indiceP).getPeso();

    // Obtener la oferta actual del paquete y su prioridad
    int indiceOfertaActual = asignacionPaquetes.get(indiceP).getValue();
    int prioOfertaActual = getPrioridad(ofertas.get(indiceOfertaActual).getDias());

    boolean mejorada = false;
    int i = 0;
    if (prioONueva < prioOfertaActual && indiceOfertaActual != indiceONueva) {
      asignacionPaquetes.set(indiceP, new AbstractMap.SimpleEntry<>(indiceP, indiceONueva));
      double nuevoPesoLibre = asignacionOfertas.get(indiceONueva).getValue() - pesoP;
      asignacionOfertas.set(indiceONueva, new AbstractMap.SimpleEntry<>(indiceONueva, nuevoPesoLibre));
      //volvemos a actualizar el peso libre de la oferta anterior
      double pesoRecalculado = asignacionOfertas.get(indiceOfertaActual).getValue()+pesoP;
      asignacionOfertas.set(indiceOfertaActual, new AbstractMap.SimpleEntry<>(indiceONueva, pesoRecalculado));
      mejorada = true;
      editarCoste(indiceP, indiceOfertaActual, indiceONueva);
      editarFelicidad(indiceP, indiceOfertaActual, indiceONueva);
    }

    return mejorada; // No se encontrÃƒÂ³ una oferta de mayor prioridad adecuada
  }

  public boolean swapPaquetesMismaPrioridad(int indicePaq1, int indicePaq2) {
    //el paquete tiene la misma prioridad pero puede ser que la oferta no (una sea igual a la prioridad del paq y la otra un nivel mejor o incluso dos)
    // Obtener la prioridad y peso del primer paquete
    int prioPaq1 = paquetes.get(indicePaq1).getPrioridad();
    double pesoPaq1 = paquetes.get(indicePaq1).getPeso();

    // Obtener la prioridad y peso del segundo paquete
    int prioPaq2 = paquetes.get(indicePaq2).getPrioridad();
    double pesoPaq2 = paquetes.get(indicePaq2).getPeso();
    // Verificar que ambos paquetes tengan la misma prioridad
    if (prioPaq1 != prioPaq2) {
      return false;
    }

    // Obtener las ofertas actuales a las que estÃƒÂ¡n asignados ambos paquetes
    int indiceOferta1 = asignacionPaquetes.get(indicePaq1).getValue();
    int indiceOferta2 = asignacionPaquetes.get(indicePaq2).getValue();

    // Evitar intercambiar el paquete con sÃƒÂ­ mismo
    if (indiceOferta1 == indiceOferta2) {
      return false;
    }

    // Obtener el peso libre en ambas ofertas
    double pesoNuevoOferta1, pesoNuevoOferta2;
    pesoNuevoOferta1 = asignacionOfertas.get(indiceOferta1).getValue()+pesoPaq1-pesoPaq2;
    pesoNuevoOferta2 = asignacionOfertas.get(indiceOferta2).getValue()+pesoPaq2-pesoPaq1;


    // Verificar que cada oferta pueda aceptar el peso del otro paquete
    if (pesoNuevoOferta1 >= 0 && pesoNuevoOferta2 >= 0) {
      // Realizar el swap en la asignaciÃƒÂ³n de paquetes
      asignacionPaquetes.set(indicePaq1, new AbstractMap.SimpleEntry<>(indicePaq1, indiceOferta2));
      asignacionPaquetes.set(indicePaq2, new AbstractMap.SimpleEntry<>(indicePaq2, indiceOferta1));
      asignacionOfertas.set(indiceOferta1, new AbstractMap.SimpleEntry<>(indiceOferta1, pesoNuevoOferta1));
      asignacionOfertas.set(indiceOferta2, new AbstractMap.SimpleEntry<>(indiceOferta2, pesoNuevoOferta2));

      editarFelicidad(indicePaq1, indiceOferta1, indiceOferta2);
      editarFelicidad(indicePaq2, indiceOferta2, indiceOferta1);
      editarCoste(indicePaq1, indiceOferta1, indiceOferta2);
      editarCoste(indicePaq2, indiceOferta2, indiceOferta1);

      return true; // Swap realizado exitosamente
    }
    return false; // No fue posible realizar el swap
  }

  public void calcularCoste(Object aState) {
    ProbIABoard board = (ProbIABoard) aState;
    List<Map.Entry<Integer, Integer>> asignacionPaquetes = board.getAsignacionPaquetes();

    double costeT = 0; //coste de transporte
    double costeA = 0; //coste de almacenamiento

    for (int i = 0; i < asignacionPaquetes.size(); ++i) {

      //sumamos al coste total el peso del paquete indicePaq por el precio/kg de la oferta indiceOferta
      int indiceOferta = asignacionPaquetes.get(i).getValue();
      int indicePaq = asignacionPaquetes.get(i).getKey();
      costeT += ProbIABoard.paquetes.get(indicePaq).getPeso() * ProbIABoard.ofertas.get(indiceOferta).getPrecio();

      //sumamos los costes de almacenamiento (0.25e por dia)
      if (ProbIABoard.ofertas.get(indiceOferta).getDias() == 3 || ProbIABoard.ofertas.get(indiceOferta).getDias() == 4) {
        costeA += 1*0.25;
      }
      else if (ProbIABoard.ofertas.get(indiceOferta).getDias() == 5) {
        costeA += 2*0.25;
      }
    }
    //System.out.println("costeT " +costeT + " costeA " +costeA);
    costeAsignacion =  costeT+costeA;

  }

  public void calcularFelicidad(Object aState) {

    ProbIABoard board = (ProbIABoard) aState;

    //calculamos felicidad total de la asignacion
    //donde sumamos una unidad a felicidad por dia que se anticipa la entrega
    for (int i = 0; i < asignacionPaquetes.size(); ++i) {
      int indiceOferta = asignacionPaquetes.get(i).getValue();
      int indicePaq = asignacionPaquetes.get(i).getKey();

      int diasEntrega = ofertas.get(indiceOferta).getDias();

      if (paquetes.get(indicePaq).getPrioridad() == 1 && diasEntrega == 0 || paquetes.get(indicePaq).getPrioridad() == 2 && diasEntrega == 1) ++felicidad;
      else if (paquetes.get(indicePaq).getPrioridad() == 2 && diasEntrega == 0) felicidad += 2;
    }
  }

  public void editarFelicidad (int indicePaq, int indiceOfertaAnterior, int indiceOfertaNueva) {
    //restamos valores antiguos
    int diasEntrega = ofertas.get(indiceOfertaAnterior).getDias();
    if (paquetes.get(indicePaq).getPrioridad() == 1 && diasEntrega == 0 || paquetes.get(indicePaq).getPrioridad() == 2 && diasEntrega == 1) --felicidad;
    else if (paquetes.get(indicePaq).getPrioridad() == 2 && diasEntrega == 0) felicidad -= 2;

    //sumamos valores nuevos
    diasEntrega = ofertas.get(indiceOfertaNueva).getDias();
    if (paquetes.get(indicePaq).getPrioridad() == 1 && diasEntrega == 0 || paquetes.get(indicePaq).getPrioridad() == 2 && diasEntrega == 1) ++felicidad;
    else if (paquetes.get(indicePaq).getPrioridad() == 2 && diasEntrega == 0) felicidad += 2;
  }

  public void editarCoste(int indicePaq, int indiceOfertaAnterior, int indiceOfertaNueva) {
    //restamos valores antigua asignacion
    costeAsignacion -= paquetes.get(indicePaq).getPeso()*ofertas.get(indiceOfertaAnterior).getPrecio();
    //sumamos valores nueva asignacion
    costeAsignacion += paquetes.get(indicePaq).getPeso()*ofertas.get(indiceOfertaNueva).getPrecio();
  }
}










