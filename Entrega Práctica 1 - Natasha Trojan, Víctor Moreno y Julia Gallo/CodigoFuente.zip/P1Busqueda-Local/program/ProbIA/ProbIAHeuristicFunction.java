package program.ProbIA;

import aima.search.framework.HeuristicFunction;

import java.util.List;
import java.util.Map;

//funcion heuristica que evalua el coste de transporte y almacenamiento
public class ProbIAHeuristicFunction implements HeuristicFunction  {

    public boolean equals(Object obj) {
        boolean retValue;
        retValue = super.equals(obj);
        return retValue;
    }

    public double getHeuristicValue(Object state) {
        ProbIABoard board = (ProbIABoard) state;
        return board.getCoste();

    }
}



