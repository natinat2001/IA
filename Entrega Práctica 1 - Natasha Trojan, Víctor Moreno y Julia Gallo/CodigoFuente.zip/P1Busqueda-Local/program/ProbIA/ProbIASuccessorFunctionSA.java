package program.ProbIA;

import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class ProbIASuccessorFunctionSA implements SuccessorFunction {

    private Random random = new Random(); // Generador aleatorio para SA

    @Override
    public List getSuccessors(Object aState) {
        ArrayList retVal = new ArrayList();
        ProbIABoard board = (ProbIABoard) aState;

        // Obtener las asignaciones actuales de paquetes y ofertas
        List<Map.Entry<Integer, Integer>> asignacionPaqsActual = board.getAsignacionPaquetes();
        List<Map.Entry<Integer, Double>> asignacionOfertasActual = board.getAsignacionOfertas();
        double costeAsignacion = board.getCoste();
        Integer felicidad = board.getFelicidad();

        // Escoger aleatoriamente un paquete para aplicar un operador
        int i = random.nextInt(asignacionPaqsActual.size());
        int indiceP = asignacionPaqsActual.get(i).getKey();
        double pesoP = board.paquetes.get(indiceP).getPeso();
        int indiceOfertaActual = asignacionPaqsActual.get(indiceP).getValue();
        int prioOfertaActual = board.getPrioridad(board.ofertas.get(indiceOfertaActual).getDias());
        double pesoLibreAnterior = asignacionOfertasActual.get(indiceOfertaActual).getValue();
        ProbIABoard nuevoEstado = new ProbIABoard(asignacionPaqsActual, asignacionOfertasActual, costeAsignacion, felicidad);

        // Elegir aleatoriamente un operador para aplicar
        int operador = random.nextInt(2); // Hay 3 operadores posibles

        switch (operador) {
            /*case 0: // Operador 1: Mover paquete a oferta de la misma prioridad
                boolean movido = false;
                int j = 0;
                while (j < board.getAsignacionOfertas().size() && !movido) {
                    int prioOfNueva = board.getPrioridad(board.ofertas.get(j).getDias());
                    int indiceNuevaOferta = asignacionOfertasActual.get(j).getKey();
                    double nuevoPesoLibre = asignacionOfertasActual.get(indiceNuevaOferta).getValue() - pesoP;
                    nuevoEstado = new ProbIABoard(asignacionPaqsActual, asignacionOfertasActual, costeAsignacion, felicidad);
                    if (prioOfertaActual == prioOfNueva) {
                        if (nuevoEstado.moverPaqueteMismaPrioridad(indiceP, indiceNuevaOferta, nuevoPesoLibre)) {

                            //System.out.println();
                            //System.out.println("size asignacionPaqsActual "+asignacionPaqsActual.size());
                            /*for (int k = 0; k < asignacionPaqsActual.size(); ++k) {
                                System.out.println("nou estat amb op1 paq " +asignacionPaqsActual.get(k).getKey() + " of "+asignacionPaqsActual.get(k).getValue());
                            }

                            String action = "Mover paquete " + indiceP + " a oferta " + indiceNuevaOferta;
                            retVal.add(new Successor(action, nuevoEstado));
                            //System.out.println("action: "+action);
                            movido = true;
                        }
                    }
                    ++j;
                }

                break;
*/

            case 0: // Operador 2: Mejorar la prioridad del paquete
                boolean mejorada = false;
                int j = 0;
                while (j < asignacionOfertasActual.size() && !mejorada) {
                    int prioOBucle = board.getPrioridad(board.ofertas.get(j).getDias());
                    nuevoEstado = new ProbIABoard(asignacionPaqsActual, asignacionOfertasActual, costeAsignacion, felicidad);
                    int indiceOBucle = asignacionOfertasActual.get(j).getKey();
                    if (nuevoEstado.mejorarPrioridadPaquete(indiceP, indiceOBucle, prioOBucle)) {

                        //System.out.println();
                        //System.out.println("size asignacionPaqsActual "+asignacionPaqsActual.size());
                        /*for (int k = 0; k < asignacionPaqsActual.size(); ++k) {
                            System.out.println("nou estat amb op2 paq " +asignacionPaqsActual.get(k).getKey() + " of "+asignacionPaqsActual.get(k).getValue());
                        }*/


                        String action = "Mover paquete " + indiceP + " a mejor oferta";
                        //System.out.println("action: "+action);
                        retVal.add(new Successor(action, nuevoEstado));
                        mejorada = true;
                    }
                    ++j;
                }
                break;

            case 1: // Operador 3: Swap entre dos paquetes
                if (i < asignacionPaqsActual.size() - 1) {
                    int p2 = random.nextInt(asignacionPaqsActual.size() - (i + 1)) + (i + 1);
                    int indiceP2 = asignacionPaqsActual.get(p2).getKey();
                    nuevoEstado = new ProbIABoard(asignacionPaqsActual, asignacionOfertasActual, costeAsignacion, felicidad);
                    if (nuevoEstado.swapPaquetesMismaPrioridad(indiceP, indiceP2)) {

                        //System.out.println();
                        //System.out.println("size asignacionPaqsActual "+asignacionPaqsActual.size());
                        /*for (int k = 0; k < asignacionPaqsActual.size(); ++k) {
                            System.out.println("nou estat amb op3 paq " +asignacionPaqsActual.get(k).getKey() + " of "+asignacionPaqsActual.get(k).getValue());
                        }*/

                        String action = "Swap paquete " + indiceP + " con paquete " + indiceP2;
                        //System.out.println("action: "+action);
                        retVal.add(new Successor(action, nuevoEstado));
                    }
                }
                break;
        }

        // Retorna una lista con solo un sucesor, el que ha sido seleccionado aleatoriamente
        return retVal;
    }
}