package program.ProbIA;

import aima.search.framework.HeuristicFunction;

import java.util.List;
import java.util.Map;

//funcion heuristica que evalua los costes de felicidad
public class ProbIAHeuristicFunction2 implements HeuristicFunction  {
    public double getHeuristicValue(Object state) {
        ProbIABoard board = (ProbIABoard) state;
        return board.getFelicidad();
    }
}
