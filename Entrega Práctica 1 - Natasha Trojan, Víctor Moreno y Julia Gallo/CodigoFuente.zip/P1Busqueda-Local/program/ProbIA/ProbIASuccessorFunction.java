package program.ProbIA;

//~--- non-JDK imports --------------------------------------------------------

import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;
import program.ProbIA.ProbIABoard;
import IA.Azamon.Transporte;

//~--- JDK imports ------------------------------------------------------------

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ProbIASuccessorFunction implements SuccessorFunction {

    @Override
    public List getSuccessors(Object aState) {
        ArrayList retVal = new ArrayList();
        ProbIABoard board = (ProbIABoard) aState;
        // Obtener las asignaciones actuales de paquetes y ofertas
        List<Map.Entry<Integer, Integer>> asignacionPaqsActual = board.getAsignacionPaquetes();
        List<Map.Entry<Integer, Double>> asignacionOfertasActual = board.getAsignacionOfertas();
        double costeAsignacion = board.getCoste();
        Integer felicidad = board.getFelicidad();

        //recorremos la asignacion actual de paquetes ASIGNACION
        for (int i = 0; i < board.getAsignacionOfertas().size(); ++i) {
            int indiceP = asignacionPaqsActual.get(i).getKey();
            double pesoP = board.paquetes.get(indiceP).getPeso();
            int indiceOfertaActual = asignacionPaqsActual.get(indiceP).getValue();
            int prioOfertaActual = board.getPrioridad(board.ofertas.get(indiceOfertaActual).getDias());
            ProbIABoard nuevoEstado = new ProbIABoard(asignacionPaqsActual, asignacionOfertasActual, costeAsignacion, felicidad);


            //----- aplicamos PRIMER OPERADOR -----

            int j = 0;
            //recorremos las ofertas de la misma prioridad y intentamos aplicar el operador de movimiento con todas
            while (j < asignacionOfertasActual.size()) {
                int prioOfNueva = board.getPrioridad(board.ofertas.get(j).getDias());
                int indiceNuevaOferta = asignacionOfertasActual.get(j).getKey();
                double nuevoPesoLibre = asignacionOfertasActual.get(indiceNuevaOferta).getValue() - pesoP;

                //nuevos successors
                nuevoEstado = new ProbIABoard(asignacionPaqsActual, asignacionOfertasActual, costeAsignacion, felicidad);
                if (prioOfertaActual == prioOfNueva) {
                    if (nuevoEstado.moverPaqueteMismaPrioridad(indiceP, indiceNuevaOferta, nuevoPesoLibre)) {
                        String action = "Mover paquete " + indiceP + "a oferta " + indiceNuevaOferta;
                        retVal.add(new Successor(action, nuevoEstado));
                        //System.out.println(action);
                    }
                }
                ++j;
            }
            // if (!movido) System.out.println("No se ha podido aplicar el operador moverPaqueteMismaPrioridad");

            //----- aplicamos SEGUNDO OPERADOR -----

            // Intentar asignar el paquete a una oferta de mayor prioridad
            j = 0;
            while (j < asignacionOfertasActual.size()) {
                int prioOBucle = board.getPrioridad(board.ofertas.get(j).getDias());
                nuevoEstado = new ProbIABoard(asignacionPaqsActual, asignacionOfertasActual, costeAsignacion, felicidad);
                int indiceOBucle = asignacionOfertasActual.get(j).getKey();
                if (nuevoEstado.mejorarPrioridadPaquete(indiceP, indiceOBucle, prioOBucle)) {
                    String action = "Mover paquete " + indiceP + "a mejor oferta";
                    retVal.add(new Successor(action, nuevoEstado));
                    //System.out.println(action);
                }
                ++j;
            }
            //if (!mejorada) System.out.println("No se ha podido aplicar el operador mejorarPrioridadPaquete");


            //----- aplicamos TERCER OPERADOR -----
            //recorremos los paquetes a partir de i+1 para intentar aplicar el swap a cada par de paquetes de la asignacion
            if (i < asignacionPaqsActual.size() - 1) {//el ultimo swap es con i =penultimo paq y j=ultimo paq
                for (int p2 = i + 1; p2 < asignacionPaqsActual.size(); ++p2) {
                    int indiceP2 = asignacionPaqsActual.get(p2).getKey();
                    nuevoEstado = new ProbIABoard(asignacionPaqsActual, asignacionOfertasActual, costeAsignacion, felicidad);
                    if (nuevoEstado.swapPaquetesMismaPrioridad(indiceP, indiceP2)) {
                        String action = "Swap paquete " + indiceP + " con paquete " + indiceP2;
                        retVal.add(new Successor(action, nuevoEstado));
                        //System.out.println(action);
                    }
                }
            }
        }
        // double v = TSPHF.getHeuristicValue(newBoard); serveix per evaluar la newBoard de cada succesor
        //pero que fem amb aquesta v?
        //System.out.println("retval.size " + retVal.size());
        //System.out.println("heuristicValue " + nuevoEstado.getHeuristicValue(board));
        return retVal;
    }
}






