package program;

import IA.Azamon.Paquetes;
import IA.Azamon.Oferta;
import IA.Azamon.Paquete;
import IA.Azamon.Transporte;
import aima.search.framework.Problem;
import aima.search.framework.Search;
import aima.search.framework.SearchAgent;
import aima.search.informed.HillClimbingSearch;
import aima.search.informed.SimulatedAnnealingSearch;

import program.ProbIA.*;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        ProbIABoard board;
        Transporte ofertas; // Proporcion --> que porcentaje del peso de los paquetes deben ser asignados (normalmente 1.0 = 100%, no?)
        Paquetes paquetes;
        Random Random =  new Random();

        int npaqs, seed_p, seed_t, state, heuristic, successor;
        double proporcion;

        if (args.length != 7 && args.length != 4) {
            System.err.println("Define los argumentos: si desea valores random escribe random y define el state, heuristic y successor" +
                    "Si no, escribe los siguientes parametros: npaqs, seed_p, proporcion, seed_t, state, heuristic y successor");
            System.exit(1);
        }

        if (args[0].equals("random")) {
            seed_p = 5;
            npaqs = Random.nextInt(100) + 1;
            System.out.println(npaqs);
            paquetes = new Paquetes(npaqs, seed_p);
            proporcion = 1.0;
            seed_t = 6;
            ofertas = new Transporte(paquetes, proporcion, seed_t);

            state = Integer.parseInt(args[1]);
            heuristic = Integer.parseInt(args[2]);
            successor = Integer.parseInt(args[3]);
        }
        else {
            seed_p = Integer.parseInt(args[1]);
            npaqs = Integer.parseInt(args[0]);
            paquetes = new Paquetes(npaqs, seed_p);

            seed_t = Integer.parseInt(args[3]);
            proporcion = Double.parseDouble(args[2]);
            ofertas = new Transporte(paquetes, proporcion, seed_t);

            state = Integer.parseInt(args[4]);
            heuristic = Integer.parseInt(args[5]);
            successor = Integer.parseInt(args[6]);

        }
        board = new ProbIABoard(paquetes, ofertas, state, heuristic);
        if (successor == 0) HillClimbing(board, heuristic);
        else if (successor == 1) SimulatedAnnealing(board, heuristic);
    }

    private static void HillClimbing(ProbIABoard Board, int heuristic) {
        System.out.println("\nHill Climbing Search -->");
        if(heuristic == 0) {
            try {
                long exec_time = System.currentTimeMillis();
                Problem p = new Problem(Board,
                        new ProbIASuccessorFunction(),
                        new ProbIAGoalTest(),
                        new ProbIAHeuristicFunction());
                System.out.println("Problem created");

                Search alg = new HillClimbingSearch();
                SearchAgent agent = new SearchAgent(p, alg);
                System.out.println();
                printActions(agent.getActions());
                ProbIABoard newboard = (ProbIABoard) alg.getGoalState();
                exec_time = System.currentTimeMillis() - exec_time;
                System.out.println();
                System.out.println("Tiempo de ejecucion(ms) = " + exec_time);
                ProbIAHeuristicFunction heuristic_alg = new ProbIAHeuristicFunction();
                System.out.println("Valor heuristico = " + (-heuristic_alg.getHeuristicValue(newboard)));
                System.out.println();
                //newboard.g
                printInstrumentation(agent.getInstrumentation());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else if( heuristic == 1) {
            try {
                long exec_time = System.currentTimeMillis();
                Problem p = new Problem(Board,
                        new ProbIASuccessorFunction(),
                        new ProbIAGoalTest(),
                        new ProbIAHeuristicFunction2());
                System.out.println("Problem created");
                Search alg = new HillClimbingSearch();
                SearchAgent agent = new SearchAgent(p, alg);
                System.out.println();
                printActions(agent.getActions());
                ProbIABoard newboard = (ProbIABoard) alg.getGoalState();
                exec_time = System.currentTimeMillis() - exec_time;
                System.out.println();
                System.out.println("Tiempo de ejecucion(ms) = " + exec_time);
                //System.out.println("Tiempo de transmisiÃƒÂ³n del servidor mÃƒÂ¡s lento(ms) = " + newboard.getSlowestServerCost());
                //System.out.println("Tiempo de transmisiÃƒÂ³n total(ms) = " + newboard.getCost());
                //System.out.println("DesviaciÃƒÂ³n = " + newboard.getDesviacio());
                System.out.println();
                printInstrumentation(agent.getInstrumentation());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void SimulatedAnnealing(ProbIABoard Board, int heuristic) {
        System.out.println("\nSimulated Annealing Search -->");
        if( heuristic == 0) {
            try {
                long exec_time = System.currentTimeMillis();
                Problem p = new Problem(Board,
                        new ProbIASuccessorFunctionSA(),
                        new ProbIAGoalTest(),
                        new ProbIAHeuristicFunction2());
                System.out.println("Problem created");
                Search alg = new SimulatedAnnealingSearch(40,100,32,0.004);
                SearchAgent agent = new SearchAgent(p, alg);
                ProbIABoard newboard = (ProbIABoard) alg.getGoalState();
                exec_time = System.currentTimeMillis() - exec_time;
                System.out.println();
                System.out.println("Tiempo de ejecuciÃƒÂ³n(ms) = " + exec_time);
                //System.out.println("Tiempo de transmisiÃƒÂ³n del servidor mÃƒÂ¡s lento(ms) = " + newboard.getSlowestServerCost());
                //(Aixo es posar valors heuristiques) System.out.println("Tiempo de transmisiÃƒÂ³n total(ms) = " + newboard.getCost());
                //System.out.println("DesviaciÃƒÂ³n = " + newboard.getDesviacio());
                System.out.println();
                printActions(agent.getActions());
                printInstrumentation(agent.getInstrumentation());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else if( heuristic == 1) {
            try {
                long exec_time = System.currentTimeMillis();
                Problem p = new Problem(Board,
                        new ProbIASuccessorFunctionSA(),
                        new ProbIAGoalTest(),
                        new ProbIAHeuristicFunction2());
                System.out.println("Problem created");
                Search alg = new SimulatedAnnealingSearch(1000000,100,25,0.01);
                SearchAgent agent = new SearchAgent(p, alg);
                ProbIABoard newboard = (ProbIABoard) alg.getGoalState();
                exec_time = System.currentTimeMillis() - exec_time;
                System.out.println();
                System.out.println("Tiempo de ejecuciÃƒÂ³n(ms) = " + exec_time);
                //System.out.println("Tiempo de transmisiÃƒÂ³n del servidor mÃƒÂ¡s lento(ms) = " + newboard.getSlowestServerCost());
                //System.out.println("Tiempo de transmisiÃƒÂ³n total(ms) = " + newboard.getCost());
                //System.out.println("DesviaciÃƒÂ³n = " + newboard.getDesviacio());
                System.out.println();
                printActions(agent.getActions());
                printInstrumentation(agent.getInstrumentation());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void printInstrumentation(Properties properties) {
        @SuppressWarnings("rawtypes")
        Iterator keys = properties.keySet().iterator();
        while (keys.hasNext()) {
            String key = (String) keys.next();
            String property = properties.getProperty(key);
            System.out.println(key + " : " + property);
        }
    }

    private static void printActions(@SuppressWarnings("rawtypes") List actions) {

        for(int i = 0; i < actions.size(); i++) {
            Object action = actions.get(i);
            if (action instanceof String) {
                System.out.println((String)action);
            }
            else if (action instanceof ProbIABoard)  {
                ProbIABoard board = (ProbIABoard) action;
            }
        }
    }
}