#!/bin/bash

# Pedir los argumentos
echo "Define los argumentos: si desea valores random escribe random y define el state, heuristic y successor"
echo "Si no, escribe los siguientes parametros: npaqs, seed_p, proporcion, seed_t, state, heuristic y successor"
read -r argumentos

# Ruta al directorio del script y proyecto
PROJECT_DIR="$(dirname "$0")"

# Archivos jar
AIMA_JAR="$PROJECT_DIR/AIMA.jar"
AZAMON_JAR="$PROJECT_DIR/Azamon.jar"

# Compilar los archivos Java
javac -cp ".:$AIMA_JAR:$AZAMON_JAR" "$PROJECT_DIR/program/Main.java"

# Verifica si Main.class ha sido generado
if [ ! -f "$PROJECT_DIR/program/Main.class" ]; then
    echo "Error: Main.class no fue generado."
    exit 1
fi

# Ejecutar el archivo principal
java -cp ".:$AIMA_JAR:$AZAMON_JAR:$PROJECT_DIR" program.Main $argumentos

rm ./program/ProbIA/*.class
rm ./program/*.class