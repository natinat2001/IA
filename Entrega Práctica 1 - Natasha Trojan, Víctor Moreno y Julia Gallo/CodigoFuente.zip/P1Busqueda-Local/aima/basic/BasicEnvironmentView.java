package aima.basic;

public class BasicEnvironmentView {

	public void envChanged(String command) {
		System.out.println(command);

	}

}