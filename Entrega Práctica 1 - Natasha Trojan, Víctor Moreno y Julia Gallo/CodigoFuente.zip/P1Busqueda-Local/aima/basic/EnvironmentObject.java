package aima.basic;

public abstract class EnvironmentObject extends ObjectWithDynamicAttributes {
	/*
	 * This represents any physical NON-AGENT object that can appear in an
	 * Environment.
	 */

}